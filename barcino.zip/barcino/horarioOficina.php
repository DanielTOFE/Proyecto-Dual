<?php 

    $page="equipos";

    include 'view/head.php';

    include 'view/header.php';
?>

<h1 style="margin-top: 2%; margin-left: 20%;"> SECRETARIA I ADMINISTRACIÓ DEL CLUB</h1>
<div style="height: 100%;">
    <div id="noticias" style="width:25%; margin-top: 5%; margin-left: 30%;">
        C/ Menorca 7-11 Barcelona (08020)
        Tel: 663.020.795
        info@pbbarcino.cat

        HORARI DE DILLUNS A DIVENDRES (dies laborables)

        Dilluns a dijous de 16 a les 20 hores
        Divendres de 16 a 19 hores
        <br>
        <br>
        <br>
        <br>
        <br>
        <br><br>
        <br>
        <br>
    </div>
</div>
<?php
    include 'view/footer.php';
?>