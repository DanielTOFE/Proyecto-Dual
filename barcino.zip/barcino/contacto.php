<?php 

    $page="contacto";


    include 'view/head.php';

    include 'view/header.php';
?>

<main>
    <h1>Contacto</h1>


    </br>
    </br>


    <b>Contacto directo del campo Menorca</b>
                    
    </br>
    </br>
    <b>Direcció:</b> C/ Menorca 7-11 Barcelona (08020)</br>
    <b>TEL.:</b> 663020795 - 663020796</br>
    <b>Direcció electrónic:</b> info@pbbarcino.cat</br>
    <b>Horari de atenció al public:</b> De dilluns a divendres de 17.00 a 22.00 horas.</br>





    <b>Contacto directo del campo Andrade</b>
                    
    </br>
    </br>
    <b>Direcció:</b> C/ Andrade 154 Cruillas C/ Treball i Selva de Mar Barcelona (08020)</br>
    <b>TEL.:</b> 663020795 - 663020796</br>
    <b>Direcció electrónic:</b> info@pbbarcino.cat</br>
    <b>Horari de atenció al public:</b> De dilluns a divendres de 17.00 a 22.00 horas.</br>


    <b>Contacto directo del campo Maresme</b>
                    
    </br>
    </br>
    <b>Direcció:</b> Carrer de Puigcerdà, 56, 08019 Barcelona</br>
    <b>TEL.:</b> 663020795 - 663020796</br>
    <b>Direcció electrónic:</b> info@pbbarcino.cat</br>
    <b>Horari de atenció al public:</b> De dilluns a divendres de 17.00 a 22.00 horas.</br>
    </br>
    </br>
</main>

<?php
    include 'view/footer.php';
?>
    
