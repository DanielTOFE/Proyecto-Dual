<?php 

    $page="equipos";

    include 'view/head.php';

    include 'view/header.php';
?>

<h1 style="margin-top: 2%; margin-left: 20%;">Noticias</h1>
<div id="noticias" style="width:25%">

    Comunicat sobre els Campus d'Estiu
    Etiqueta: General, 29/04/2021
    Barcelona 29 d'abril de l'2021.
    Benvolgut soci-a:
    Aquesta circular o missiva és per a informar-vos, que davant els comentaris que ens arriben 
    pel que fa a al campus d'estiu, aclarir totes les preguntes i dubtes que pugueu tenir.
    Després d'estar organitzant el campus, durant un període de més de 15 anys la directiva 
    de la Penya va decidir que aquesta temporada 2020-2021 no organitzar els campus de Nadal, 
    Setmana Santa i estiu.
    Per la qual cosa aquest any els organitzadors, seran entitats o empreses alienes a club, 
    les que organitzaran els campus a les diferents instal·lacions que gestiona la P. B. Barcino.
    Volem deixar ben clar que la P. B. Barcino no és una empresa, que no té responsabilitat organitzativa 
    en cap dels campus organitzats, no té conveni especial amb cap de les entitats o empreses organitzadores.
    Sense més atentament.


    La Junta Directiva.
</div>
<?php
    include 'view/footer.php';
?>
    