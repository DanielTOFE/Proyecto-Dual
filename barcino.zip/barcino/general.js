var miDiv = document.getElementById("popup-bg");

function abrirPopup() {
   miDiv.style.display = "block";
}

function cerrarPopup() {
   miDiv.style.display = "none";
}