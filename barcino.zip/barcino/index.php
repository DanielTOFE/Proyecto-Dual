<?php 

    $page="home";

    include 'view/head.php';

    include 'view/header.php';
    
?>

<main>
<img class="imgbody" src="./view/imagenes/bodygeneral/banderaBarcino.jpg">
    

</main>

<?php
    include 'view/footer.php';
?>
    
