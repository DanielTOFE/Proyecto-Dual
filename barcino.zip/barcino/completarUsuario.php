<form method="GET" action="./funciones/completarusuario.php">
                        <div class="form-group">
                          <label for="recipient-name" class="col-form-label">Nombre:</label>
                          <input name="nombre" type="text" class="form-control" id="recipient-name"><br>
                          <label for="recipient-name" class="col-form-label">Primer apellido:</label>
                          <input type="primer-apellido" name="contrasenya" type="text" class="form-control" id="recipient-name"><br>
                          <label for="recipient-name" class="col-form-label">Segundo Apellido:</label>
                          <input name="segundo-apellido" type="text" class="form-control" id="recipient-name"><br>

                          <label for="recipient-name" class="col-form-label">Telefono:</label>
                          <input name="telefono" type="text" class="form-control" id="recipient-name"><br>
                          <label for="recipient-name" class="col-form-label">Ciudad:</label>
                          <input name="ciudad" type="text" class="form-control" id="recipient-name"><br>
                          <label for="recipient-name" class="col-form-label">Codigo Postal:</label>
                          <input name="codigo-postal" type="text" class="form-control" id="recipient-name"><br>
                          <div class="form-group">
                            <label>Genero:</label>
                            <label class="radio-inline">
                            <input type="radio" class="form-control" name="gender">Female</label>
                            <label class="radio-inline">
                            <input type="radio" class="form-control" name="gender">Male</label>
                        </div>  
                          <label for="recipient-name" class="col-form-label">Posicion:</label>
                          <input name="posicion" type="text" class="form-control" id="recipient-name"><br>
                          <label for="recipient-name" class="col-form-label">Fecha Nacimiento:</label>
                          <input name="fecha-nacimiento" type="text" class="form-control" id="recipient-name"><br>
                        </div>
                        <div class="form-group">
                          
                        </div>
                        <div class="modal-footer">
                          <input type="submit" name="Submit" value="Guardar Perfil" />

                          </div>
                      </form>
                      

-- he de poner que se acepte cn la bbd