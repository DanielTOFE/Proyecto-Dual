
<button onclick="location.href='http://localhost/barcino/completarUsuario.php'" type="button" class="btn btn-outline-success" data-whatever="@getbootstrap">Perfil</button>
<button onclick="location.href='http://localhost/barcino/cerrarSesion.php'" type="button" class="btn btn-outline-danger" data-whatever="@getbootstrap">Salir de sesion</button>
