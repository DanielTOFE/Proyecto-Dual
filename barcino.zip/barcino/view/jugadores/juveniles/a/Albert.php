


<?php 

$page="equipos";

include './../view/head.php';

include './../view/header.php';
?>

<main>
<h1>Juvenil A</h1>

    <h2>

    <div class="row">
                <div class="col-sm-6 col-md-2">
                    <div class="thumbnail">
                    <img src="./../view/imagenes/jugadorPlantilla.png"  type="button" href="#" width="170" height="140"><br>Albert</a>
                    <div class="caption">
                        <h3>Portero</h3>
                        
                        <p>
                        <a>Fecha Nacimiento: 10/04/2000</a><br>
                        <a>Nacionalidad: Española</a><br>
                        <a>Descripcion: Es un jugador que no teme al uno contra uno, y muy agil tanto bajo palos como en salidas aereas.</a><br>
                        </p>
                    </div>
                    </div>
                </div>
    </div>
                
    </h2>

</main>

<?php
    include './../view/footer.php';
?>
    
