<form method="GET" action="funciones/inicioSesion.php" class="form-inline my-2 my-lg-0">
    <input name="usuario" class="form-control mr-sm-2" type="search" placeholder="Usuario" id="tags" aria-label="Search">
    <input type="password" name="contrasenya" class="form-control mr-sm-2" type="search" placeholder="Contraseña" id="tags" aria-label="Search">
    <input type="submit" name="Submit" value="Iniciar Sesion" />
    
</form>