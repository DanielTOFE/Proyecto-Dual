<?php 

    $page="equipos";

    include 'view/head.php';

    include 'view/header.php';
?>

<h1>Canticos</h1>
<main>
    <div class ="canticos" style="background-color: #fafafa;
  margin: 1rem;
  padding: 1rem;
  border: 2px solid #ccc;
  text-align: center;">
    <h1>HIMNE DEL CLUB</h1> <br>
 
        Barcino, SEMPRE ENDAVANT!<br>
        

        
        LLETRA<br>
        
        Barcino, Barcino, Barcino sempre endavant!<br>
        
        no tinguem por del que vindrà<br>
        
        el futur hem de guanyar!<br>
        
        Barcino, Barcino, Barcino sempre endavant!<br>
        
        que la nostra fe en la victòria<br>
        
        a tothom faci vibrar!<br>
        
        Portem amb orgull el blau escapulari<br>
        
        sentim els colors ben endintre del cor<br>
        
        Barcino, Barcino, Barcino sempre endavant!<br>
        
        que la nostra fe en la victòria<br>
        
        a tothom faci vibrar...<br>
        
        i que la nostra gran història<br>
        
        poc a poc puguem retrobar!<br>
        
        Barcino, Barcino, Barcino... ENDAVANT, ENDAVANT!<br>
        
        
        <div style="background-color: #fafafa;
  margin: 1rem;
  padding: 1rem;
  border: 2px solid #ccc;
  text-align: center;">

        AUTOR: David Cabellos · ANY: 2003 <br>
        CANTANTS: Moisés Vigas, Lluis Maroto i Georgina Solá
        </div>
    </div>
</main>
<?php
    include 'view/footer.php';
?>