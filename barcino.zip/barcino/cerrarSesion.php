<?php

include './index.php';
session_unset();
// a veces me funciona bien, a veces hay que darle dos veces al salir, el primero sale del usuario pero no refresca el navbar como index sino como zonaprivada aun.
?>