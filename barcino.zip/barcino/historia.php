<?php 

    $page="equipos";

    include 'view/head.php';

    include 'view/header.php';


?>
    


    <h1 style="margin-top: 2%; margin-left: 20%;">Historia</h1>
    <div class="col" style="width: 30%;">
        <div id="hisotria1">
        <h2>La Penya Barcelonista Barcino és una entitat que va ser creada l'any 1949 sota el nom de Club Esportiu Barcino. Anys després, i ja sota el seu nom actual, va entrar a formar part de L'Agrupació de penyes del futbol Club Barcelona.Des dels seus inicis la P.B.Barcino ha estat una entitat social i esportiva, que ha tingut dues finalitats ben clares i definides, en primer lloc la prática de l'esport del futbol, i en segon lloc la formació com a persones de tots aquells joves que han format part del nostre club.</h2>
        </div>
        
        <div id="hisotria1">
        <h2>A la temporada 1981-82 va absorbir la Penya Barcelonista Bailen, per tal d'augmentar el seu potencial esportiu.Al llarg de la seva histtóia el nostre club ha tingut la seva seu a diferents camps de futbol, períodes de la temporada 1997/98, any en que és va inagurar les instal.lacions esportives de el Clot de la Mel, la nostra entitat desemvolupa aqui part de les seves activitats esportives.Des de la temporada 2001-2002 som els gestors del camp de fútbol municipal Menorca, on es juguen actualment la majoria dels nostres partits de fútbol.</h3>
        </div>

        <div id="hisotria1">
        <h2>La P.B.Barcino gaudeix en la actualitat d'un gran arrelament dins del barri de Sant Marti de Provençals, per l'area de influència del nostre club s'estén a tota la zona del Barcelonés, at que la procedéncia de la nostre massa social és de diferents barris de la ciutat de Barcelona aixi com d'altres poblacions de les rodalies, tal com Santa Coloma de Gramanet, Sant Adrià del Besòs, Badalona, etc.</h4>
        </div>

    </div>        


<?php
    include 'view/footer.php';
?>