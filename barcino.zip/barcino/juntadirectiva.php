<?php 

    $page="contacto";


    include 'view/head.php';

    include 'view/header.php';
?>
    <h1 style="margin-top: 2%; margin-left: 40%;">Junta Directiva</h1>
<div class=" align-items-center justify-content-center vh-10">

<div class="col-sm-6 col-md-2">
    <div class="thumbnail" style="margin-top: 2%; margin-left: 40%;">
        <img src="./view/imagenes/juntadirectiva/tomas_desembre.jpg"  type="" href="#" width="380" height="300"><br></a>
        <div class="caption">
            <b>Tomas Desembre</b>
            <p><b>President</b></p>       

        </div>
    </div>
</div>



<div class="col-sm-6 col-md-12">
    <div class="thumbnail" style="margin-top: 2%; margin-left: 55%;">
        <img src="./view/imagenes/juntadirectiva/angel_bergel.jpg"  type="" href="#" width="380" height="300"><br></a>
       
        <div class="caption">
            <b>Angel Bergel</b>
            <p><b>Area Deportiva</b></p>       

        </div>
    </div>
</div>



<div class="col-sm-6 col-md-2">
    <div class="thumbnail" style="margin-top: 2%; margin-left: 40%;">
        <img src="./view/imagenes/juntadirectiva/jose_maria.jpg"  type="" href="#" width="380" height="300"><br></a>
        <div class="caption">
            <b>Jose Maria Lopez</b>
            <p><b>Area Deportiva</b></p>       

        </div>
    </div>
</div>



<div class="col-sm-6 col-md-12">
    <div class="thumbnail" style="margin-top: 2%; margin-left: 55%;">
        <img src="./view/imagenes/juntadirectiva/enric_desembre.jpg"  type="" href="#" width="380" height="300"><br></a>
        <div class="caption">
            <b>Enric Desembre</b>
            <p><b>Tresorer</b></p>       

        </div>
    </div>
</div>



<div class="col-sm-6 col-md-2">
    <div class="thumbnail" style="margin-top: 2%; margin-left: 40%;">
        <img src="./view/imagenes/juntadirectiva/maria_martinez.jpg"  type="" href="#" width="380" height="300"><br></a>
        <div class="caption">
            <b>Maria Martinez</b>
            <p><b>Secretaria</b></p>       

        </div>
    </div>
</div>

<?php
    include 'view/footer.php';
?>
    
