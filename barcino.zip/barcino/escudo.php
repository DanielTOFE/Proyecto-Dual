<?php 

    $page="equipos";

    include 'view/head.php';

    include 'view/header.php';
?>

<h1 style="margin-top: 2%; margin-left: 30%;">Historia de los Escudos</h1>
<div class="caja" style="justify-content: center; align-items: center; background: #ffffff;">
    <div class="box" style="width: 350px;vheight: 250px; background: #ffffff;">
        <img src="view/imagenes/escudos/escudoActual.png" alt="Escudo actual">
        <br>
        <h2>Escudo Actual</h2>

    </div>
</div>

<?php
    include 'view/footer.php';
?>